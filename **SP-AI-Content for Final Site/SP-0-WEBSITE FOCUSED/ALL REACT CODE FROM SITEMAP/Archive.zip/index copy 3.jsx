import React from "react";
import { Navbar7 } from "./components/Navbar7";
import { Content28 } from "./components/Content28";

export default function Page() {
  return (
    <div>
      <Navbar7 />
      <Content28 />
    </div>
  );
}
