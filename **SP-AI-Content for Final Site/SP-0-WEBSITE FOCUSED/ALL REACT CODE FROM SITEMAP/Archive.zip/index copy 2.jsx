import React from "react";
import { Header46 } from "./components/Header46";
import { Content27 } from "./components/Content27";

export default function Page() {
  return (
    <div>
      <Header46 />
      <Content27 />
    </div>
  );
}
